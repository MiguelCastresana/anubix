#' Example data provided with the package
#'
#' @description List collecting example data to be able to run ANUBIX
#' \itemize{
#'   \item \strong{links_genes}   -   The number of links each human gene has to KEGG pathways using a link confidence cutoff in the functional association network Funcoup 4.1 of 0.75. Dimensions 12444 rows (genes) and 288 columns (pathways)
#'   \item \strong{pathway_set}   -   288 KEGG pathways for \emph{Homo sapiens}.
#'   \item \strong{gene_set} -   Example gene set with 42 genes.
#'   \item \strong{network}  -   A subset from the Funcoup network for \emph{Homo sapiens}. 2000 links and 1788 genes.
#' }
#'
#' @seealso \code{\link{anubix}},\code{\link{anubix_links}},\code{\link{anubix_clustering}}
#'
#'
#' @source
#' \itemize{
#'   \item{\strong{pathway_set: }} Kanehisa, M., and Goto, S. (2002). KEGG: Kyoto Encyclopedia of Genes and Genomes. Nucleic Acids Res., 28(1), 27-30.
#'   \item{\strong{network: }} Schmitt,T., Ogris,C. and Sonnhammer,E.L.L. (2014) FunCoup 3.0: database of genome-wide functional coupling networks. Nucleic Acids Res., 42, D380–8.
#' }
#'
#' @references
#' \itemize{
#'   \item Kanehisa, M., and Goto, S. (2002). KEGG: Kyoto Encyclopedia of Genes and Genomes. Nucleic Acids Res., 28(1), 27-30.
#'   \item Schmitt,T., Ogris,C. and Sonnhammer,E.L.L. (2014) FunCoup 3.0: database of genome-wide functional coupling networks. Nucleic Acids Res., 42, D380–8.
#' }
#'
#' @examples
#' \dontrun{
#'  data(example_anubix)
#'
#'
#' # We provide with the precomputed matrix for Funcoup with a cutoff of 0.75 to run ANUBIX directly.
#' # However, to show an example for the link computation we use an a subset of funcoup network.
#'
#'
#'  anubix_links(example_anubix$network,2,example_anubix$pathway_set,cutoff = 0.75, "weighted")
#'
#'  # Performs ANUBIX. We provide with the data necessary to run it directly.
#'
#'  anubix(links_matrix = example_anubix$links_genes,genesets = example_anubix$gene_set,
#'  pathways = example_anubix$pathway_set,cores = 2,total_genes = 20000, sampling = 2000)
#'
#' }
"example_anubix"
