
#' Perform ANUBIX for the provided gene sets
#'
#' @description Computes ANUBIX, an accurate test for network enrichment analysis between query sets and pathway sets.
#' @usage anubix(links_matrix, genesets, pathways, cores = 2,
#' total_genes, sampling = 2000)
#' @param links_matrix A numeric matrix. Links_matrix stores the links each gene has to each pathway. The number of rows equals to the number of genes in the network and the number of columns equals to the number of pathways under study.
#' @param genesets A data.frame of two columns. Column 1, are the genes and column 2 the experiment where they belong to.
#' @param pathways A data.frame of two columns. Column 1 are the genes and second column the pathway where they belong to.
#' @param cores A numeric value. Cores is defined as the number of cores used by the algorithm. The default value is \strong{2}
#' @param sampling A numeric value. Sampling is defined as the number of random samplings required to construct the null distribution. The default value is \strong{2000}
#' @param total_genes A numeric value. Total_genes is defined as the total number of genes that the organism under study has. For human we use \strong{20000}
#' @importFrom TailRank dbb
#' @importFrom dplyr %>% select
#' @importFrom optimr optimr
#' @importFrom stats p.adjust
#' @import parallel
#' @export
#' @return A data frame with the following columns:
#' \itemize{
#'   \item geneset   -   Gene set under study.
#'   \item pathway   -   Pathway under study.
#'   \item obv_links -   Observed number of links between the gene set and the pathway.
#'   \item exp_mean  -   Expected number of links between the gene set and the pathway.
#'   \item overlap   -   Number of genes shared by the gene set and the pathway
#'   \item p-value   -   p-value of the test.
#'   \item q-value   -   Corrected p-value using Benjamini-Hochberg.
#'   \item FWER      -   Corrected p-value using Bonferroni correction.
#' }
#'
#' @seealso \code{\link{anubix_links}},\code{\link{example_anubix}},\code{\link{anubix_clustering}}
#'
#'
#'
#' @examples
#' # We provide with example data to be able to run ANUBIX.
#' \dontrun{
#'  anubix(links_matrix = example_anubix$links_genes,genesets = example_anubix$gene_set,
#'  pathways = example_anubix$pathway_set,cores = 2,total_genes = 20000, sampling = 2000)
#' }



anubix = function(links_matrix,
                  genesets,
                  pathways,
                  cores = 2,
                  total_genes,
                  sampling = 2000,
                  callback = NULL,
                  website = FALSE) {
  if (is.null(links_matrix)) {
    stop("Precomputed file for the links per gene is missing",
         call. = FALSE)
  }
  else if (is.null(genesets)) {
    stop("Query gene sets are missing", call. = FALSE)
  }
  else if (is.null(pathways)) {
    stop("Pathway file is missing", call. = FALSE)
  }
  else if (is.null(cores)) {
    cores = 2
  }
  else if (is.null(total_genes)) {
    stop("Number of genes in the proteome is missing", call. = FALSE)
  }
  else if (is.null(sampling)) {
    sampling = 2000
  }
  if (is.null(links_matrix) | class(links_matrix) != "data.frame")
    stop("Please introduce the proper data for the link count for each gene.")
  if (class(cores) != "numeric" | detectCores() < cores)
    stop("Please introduce a proper value.")
  if (ncol(genesets) < 2)
    stop("Please introduce the right format for the gene sets.")
  if (is.null(pathways) | class(pathways) != "data.frame" |
      ncol(pathways) != 2)
    stop("Pathways missing or the file is not in a proper format.")
  if (is.null(total_genes) | class(total_genes) != "numeric")
    stop("Please introduce the total number of genes in the studied organism.")
  if (class(sampling) != "numeric")
    stop("Please introduce a correct value for the total number of random samplings.")

  pathways = pathways[which(pathways[,2]%in%colnames(links_matrix)),]
  group_sets = unique(as.vector(genesets[, 2]))
  group_paths = unique(as.vector(pathways[, 2]))
  length_genesets = numeric()
  i = 1
  for (i in 1:length(group_sets)) {
    sub = genesets[which(genesets[, 2] %in% group_sets[i]),]
    length_genesets[i] = nrow(sub)
  }
  length_pathways = numeric()
  i = 1
  for (i in 1:length(group_paths)) {
    sub = pathways[which(pathways[, 2] %in% group_paths[i]),]
    length_pathways[i] = nrow(sub)
  }
  index_genes = rownames(links_matrix)
  samples = function(length_genesets) {
    g = sample(1:total_genes, length_genesets, replace = F)
    g = g[which(g <= length(index_genes))]
    return(g)
  }
  if (length(length_genesets) > 100) {
    set = seq(from = 100,
              to = length(length_genesets),
              by = 100)
    set[length(set)] = length(length_genesets)
  }
  else {
    set = length(length_genesets)
  }
  loglik = function(inits, x) {
    A <- inits[1]
    B <- inits[2]
    Y = x[, 3]
    N = x[, 2]
    - sum(
      lgamma(abs(A) + abs(B)) - lgamma(abs(A)) - lgamma(abs(B)) +
        lgamma(Y + abs(A)) + lgamma(N - Y + abs(B)) - lgamma(N +
                                                               abs(A) + abs(B))
    )
  }
  links_geneset = function(geneset) {
    links = links_matrix[geneset,]
    links = sapply(links, function(x)
      sum(x))
    links = unname(links, force = FALSE)
    return(links)
  }
  stat_computation = function(c, observed1, max1) {
    n = max1
    m_1 = mean(sol[[c]])
    m_2 = mean(sol[[c]] ^ 2)
    alpha = (n * m_1 - m_2) / (n * (m_2 / m_1 - m_1 - 1) + m_1)
    beta = (n - m_1) * (n - m_2 / m_1) / (n * (m_2 / m_1 - m_1 -
                                                 1) + m_1)
    inits = c(alpha, beta)
    if (any(is.nan(inits)) == TRUE) {
      pvalue = NA
    }
    else if (any(inits == 0) == TRUE) {
      pvalue = NA
    }
    else {
      dat = as.data.frame(cbind(1:times, rep(max1, times),
                                sol[[c]]))
      optim.tas = optimr(inits, fn = loglik, x = dat)
      optim.tas$par = abs(optim.tas$par)
      pvalue = 0.5 * dbb(observed1, max1, optim.tas$par[1],
                         optim.tas$par[2]) + sum(dbb((observed1 + 1):(max1),
                                                     (max1),
                                                     optim.tas$par[1],
                                                     optim.tas$par[2]
                         ))
    }
    return(pvalue)
  }

  filtered_genesets = genesets[which(as.vector(genesets[,
                                                        1]) %in% index_genes),]
  groups = as.vector(unique(filtered_genesets[, 2]))
  i = 1
  query_list = list()
  for (i in 1:length(groups)) {
    sub = filtered_genesets[which(filtered_genesets[,
                                                    2] %in% groups[i]), 1]
    pos = which(index_genes %in% sub)
    query_list[[i]] = pos
  }

  # For the overlap
  i = 1
  overlap_list = list()
  for (i in 1:length(groups)) {
    sub = as.vector(genesets[which(genesets[, 
                                            2] %in% groups[i]), 1])
    
    overlap_list[[i]] = sub
  }
  


  if (website == TRUE) {

    group_sets = unique(as.vector(genesets[, 2]))
    group_paths = unique(as.vector(pathways[, 2]))
    length_genesets = numeric()
    i = 1
    for(i in 1:length(group_sets)){

      sub = genesets[which(genesets[,2]%in%group_sets[i]),]
      length_genesets[i] = nrow(sub)
    }
    length_pathways = numeric()
    i = 1
    for(i in 1:length(group_paths)){

      sub = pathways[which(pathways[,2]%in%group_paths[i]),]
      length_pathways[i] = nrow(sub)
    }

    index_genes = rownames(links_matrix)
    # links_matrix = links_matrix[, -1]

    samples = function(length_genesets) {

      g = sample(1:total_genes, length_genesets, replace = F)
      g = g[which(g <= length(index_genes))]
      # g = rownames(links_matrix)[g]
      return(g)
    }

    if(length(length_genesets)>100){set =   seq(from=100,to=length(length_genesets),by = 100)
    set[length(set)] = length(length_genesets)}else{set = length(length_genesets)}



    loglik = function(inits) {
      A <- inits[1]
      B <- inits[2]
      Y = dat[, 3]
      N = dat[, 2]
      - sum(
        lgamma(abs(A) + abs(B)) - lgamma(abs(A)) - lgamma(abs(B)) + lgamma(Y + abs(A)) + lgamma(N -
                                                                                                  Y + abs(B)) - lgamma(N + abs(A) + abs(B))
      )
    }

    links_geneset = function (geneset) {
      links = links_matrix[geneset, ]
      links = sapply(links, function(x)
        sum(x))
      links = unname(links, force = FALSE)
      return(links)
    }

    total = 0
    result_t = data.frame()
    timer = 1
    cc = 1

    for (timer in 1:length(set)) {
      no_cores <- cores
      cl <- makeCluster(no_cores)


      times = sampling

      clusterExport(cl,
                    list("samples", "total_genes", "index_genes", "times"),
                    envir = environment())


      length_geneset1 = length_genesets[cc:set[timer]]

      prueba1 = parSapply(cl, length_geneset1, function(x)
        lapply(1:times, function(y)
          samples(x)))

      clusterExport(cl, list("links_geneset", "links_matrix"), envir = environment())
      query = parLapply(cl, prueba1, function(x)
        links_geneset(x))

      m <- length(query[[1]])
      clusterExport(cl, list("m", "query"), envir = environment())
      remove(prueba1)
      information_list_true = parLapply(cl, 1:m, function(j)
        sapply(query, "[[", j))
      remove(query)
      stopCluster(cl)

      filtered_genesets = genesets[which(as.vector(genesets[, 1]) %in% index_genes),]
      groups = as.vector(unique(filtered_genesets[, 2]))
      i = 1
      query_list = list()
      for (i in 1:length(groups)) {
        sub = filtered_genesets[which(filtered_genesets[, 2] %in% groups[i]), 1]
        pos = which(index_genes %in% sub)
        query_list[[i]] = pos

      }
      real_genesets = lapply(query_list[cc:set[timer]], function(x)
        links_geneset(x))




      nose = numeric()
      names(real_genesets) = groups[cc:set[timer]]
      paths = as.vector(unique(pathways[, 2]))

      pvalue = numeric()
      exp_mean = numeric()
      gene_sets = vector()
      pathwys = vector()
      obv_links = numeric()
      overlapp = numeric()
      i = 1
      y = 1
      k = 1
      d = times
      for (i in 1:length(real_genesets)) {
        j = 1
        for (j in 1:length(information_list_true)) {
          obv = as.numeric(as.vector(real_genesets[[i]][j]))
          subset = information_list_true[[j]][y:d]
          g_set = as.vector(genesets[, 1][which(genesets[, 2] %in% names(real_genesets[i]))])
          overlap = length(g_set[which(g_set %in% as.vector(pathways[which(pathways[, 2] %in%
                                                                             paths[j]), 1]))])
          # if(is.na(overlap)==TRUE){overlap = 0}
          max = as.numeric((length_geneset1[i] * length_pathways[j]) - min(length_geneset1[i],length_pathways[j]))


          # if (mean(subset) == 0) {
          #   subset[times] = 1
          # }


          n = max
          m_1 = mean(subset)
          m_2 = mean(subset ^ 2)

          alpha = (n * m_1 - m_2) / (n * (m_2 / m_1 - m_1 - 1) + m_1)
          beta = (n - m_1) * (n - m_2 / m_1) / (n * (m_2 / m_1 - m_1 - 1) +
                                                  m_1)

          inits = c(alpha, beta)


          if (any(is.nan(inits)) == TRUE) {
            next
          }
          if (any(inits <= 0) == TRUE) {
            next
          }
          dat = as.data.frame(cbind(1:times, rep(max, times), subset))
          optim.tas = optimr(inits, loglik)

          optim.tas$par = abs(optim.tas$par)



          pvalue[k] = 0.5 * dbb(obv, max, optim.tas$par[1], optim.tas$par[2]) + sum(dbb((obv +
                                                                                           1):(max),
                                                                                        (max),
                                                                                        optim.tas$par[1],
                                                                                        optim.tas$par[2]
          ))

          exp_mean[k] = mean(subset)
          obv_links[k] = obv
          gene_sets[k] = names(real_genesets[i])
          pathwys[k] = paths[j]
          overlapp[k] = overlap
          k = k + 1

          # if callback is set, use it to send back the message:
          if (!is.null(callback)) {
            callback(paste(length(paths) - j, " pathways remaining", sep = ""))
          }
          print(paste(length(paths) - j, " pathways remaining", sep = ""))
        }
        y = y + times
        d = d + times
        total = total + 1
        if (!is.null(callback)) {
          callback(paste(sum(set) - total, " gene sets remaining", sep = ""))
        }
        print(paste(sum(set) - total, " gene sets remaining", sep = ""))
      }

      result = as.data.frame(cbind(gene_sets, pathwys, obv_links, exp_mean, overlapp, pvalue))
      result[, 7] = p.adjust(pvalue, method = "BH")
      # result[, 7] = p.adjust(pvalue, method = "BH")
      # result[, 7] = p.adjust(result[, 6], method = "bonferroni")
      result[, 8] = p.adjust(pvalue, method = "bonferroni")
      result[, 3] = as.numeric(as.vector(result[, 3]))
      result[, 4] = as.numeric(as.vector(result[, 4]))
      result[, 5] = as.numeric(as.vector(result[, 5]))
      result[, 6] = as.numeric(as.vector(result[, 6]))

      result_t = rbind(result_t, result)

      cc = set[timer] + 1



    }
    names(result_t) = c("geneset",
                        "pathway",
                        "obv_links",
                        "exp_mean",
                        "overlap",
                        "p-value",
                        "q-value",
                        "FWER")


  } else{
    total = 0
    timer = 1
    cc = 1
    result_t <- list()
    for (timer in 1:length(set)) {

      no_cores <- cores
      cl <- makeCluster(no_cores)
      times = sampling
      clusterExport(cl,
                    list("samples", "total_genes", "index_genes",
                         "times"),
                    envir = environment())
      length_geneset1 = length_genesets[cc:set[timer]]
      group_sets1 = group_sets[cc:set[timer]]

      prueba1 = parSapply(cl, length_geneset1, function(x)
        lapply(1:times,
               function(y)
                 samples(x)))
      clusterExport(cl, list("links_geneset", "links_matrix"),
                    envir = environment())
      query = parLapply(cl, prueba1, function(x)
        links_geneset(x))
      m <- length(query[[1]])
      clusterExport(cl, list("m", "query"), envir = environment())
      remove(prueba1)
      information_list_true = parLapply(cl, 1:m, function(j)
        sapply(query,
               "[[", j))
      remove(query)
      #
      t1 = Sys.time()
      real_genesets = lapply(query_list[cc:set[timer]], function(x)
        links_geneset(x))
      stopCluster(cl)
      no_cores <- cores
      cl <- makeCluster(no_cores)
      clusterExport(
        cl,
        list(
          "information_list_true",
          "real_genesets",
          "query_list",
          "links_matrix",
          "times",
          "group_paths",
          "pathways",
          "length_pathways",
          "length_geneset1"
        ),
        envir = environment()
      )

      sol = parSapply(cl, information_list_true, function(x)
        split(x,
              ceiling(seq_along(x) /
                        times)))
      clusterExport(cl, list("sol"), envir = environment())

      remove(information_list_true)
      observed = as.vector(unlist(real_genesets))
      g_set = parLapply(cl, overlap_list[cc:set[timer]], function(x)
        as.vector(unlist(x)))
      # g_set = parLapply(cl, g_set, function(x)
      #   rownames(links_matrix)[x])
      overlapp = parLapply(cl, g_set, function(x)
        as.vector(sapply(group_paths,
                         function(y)
                           length(x[which(x %in% as.vector(pathways[which(pathways[,
                                                                                   2] %in% y), 1]))]))))
      overlapp = unlist(overlapp)
      remove(g_set)
      length_pathways = as.numeric(as.vector(length_pathways))
      length_genesets1 = as.numeric(as.vector(length_geneset1))
      max = unlist(parLapply(cl, length_geneset1, function(x)
        as.vector(
          sapply(length_pathways,
                 function(y)
                   (y * x) - min(y,x))
        )))
      # max = max - overlapp

      stopCluster(cl)

      positions = seq(
        from = 1,
        to = length(length_pathways) * length(length_geneset1),
        by = length(length_geneset1)
      )
      positions = rep(positions, length(length_geneset1))
      summ = rep(0:(length(length_geneset1) - 1), each = length(length_pathways))
      positions = positions + summ
      n.cores = cores
      if (.Platform$OS.type == "windows") {
        n.cores = 1
      }

      pvalues = as.vector(unlist(
        mcmapply(
          function(x, y, z)
            stat_computation(x,
                             y, z),
          positions,
          observed,
          max,
          mc.cores = n.cores
        )
      ))
      expected = as.numeric(unlist(lapply(sol, function(x)
        mean(x))))
      remove(sol)
      expected = expected[positions]
      result = as.data.frame(cbind(
        rep(group_sets1, each = length(length_pathways)),
        rep(group_paths, length(length_genesets1)),
        observed,
        expected,
        overlapp,
        pvalues
      ))

      result_t[[timer]] = result
      remove(result)
      remove(pvalues)
      remove(expected)
      remove(positions)
      remove(overlapp)
      cc = set[timer] + 1
      print(timer)

      # if(timer>1){break}
    }
    tmsig1 = Sys.time()
    result_t = do.call(rbind, result_t)
    result_t[, 3] = as.numeric(as.vector(result_t[, 3]))
    result_t[, 4] = as.numeric(as.vector(result_t[, 4]))
    result_t[, 5] = as.numeric(as.vector(result_t[, 5]))
    result_t[, 6] = as.numeric(as.vector(result_t[, 6]))
    result_t = result_t[complete.cases(result_t),]
    result_t[, 7] = p.adjust(result_t[, 6], method = "BH")
    result_t[, 8] = p.adjust(result_t[, 6], method = "bonferroni")
    names(result_t) = c("geneset",
                        "pathway",
                        "obv_links",
                        "exp_mean",
                        "overlap",
                        "p-value",
                        "q-value",
                        "FWER")
  }

  return(result_t)
}
